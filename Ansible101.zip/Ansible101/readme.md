# Iniciando con Ansible

## Preliminares
Para realizar las prácticas debes tener instalado en el equipo o servidor de pruebas:
  - Docker
  - Python

#### Instalación de Ansible

        pip install ansible

### Construcción de la imagen personalizada
Ingresa a la carpeta 'ansible000' y sigue los pasos indicados.

## Reiniciar todo
En caso de reiniciar el experiemento ejecute:

    ./clean_all.sh
